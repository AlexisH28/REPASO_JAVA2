public class Pieza {
    private final TipoPieza tipo;
    private Posicion posicion;

    public Pieza(TipoPieza tipo, Posicion posicion) {
        this.tipo = tipo;
        this.posicion = posicion;
    }

    public TipoPieza getTipo() { return tipo; }
    public Posicion getPosicion() { return posicion; }
    public void setPosicion(Posicion posicion) { this.posicion = posicion; }

    public boolean esMovimientoValido(Posicion destino, TableroAjedrez tablero) {
        if (!destino.esValida()) return false;

        switch (tipo) {
            case REY:
                return esMovimientoReyValido(destino);
            case DAMA:
                return esMovimientoDamaValido(destino, tablero);
            case ALFIL:
                return esMovimientoAlfilValido(destino, tablero);
            case CABALLO:
                return esMovimientoCaballoValido(destino);
            case TORRE:
                return esMovimientoTorreValido(destino, tablero);
            default:
                return false;
        }
    }

    private boolean esMovimientoReyValido(Posicion destino) {
        int difFila = Math.abs(destino.getFila() - posicion.getFila());
        int difColumna = Math.abs(destino.getColumna() - posicion.getColumna());
        return difFila <= 1 && difColumna <= 1 && (difFila > 0 || difColumna > 0);
    }

    private boolean esMovimientoDamaValido(Posicion destino, TableroAjedrez tablero) {
        return esMovimientoTorreValido(destino, tablero) || esMovimientoAlfilValido(destino, tablero);
    }

    private boolean esMovimientoAlfilValido(Posicion destino, TableroAjedrez tablero) {
        int difFila = Math.abs(destino.getFila() - posicion.getFila());
        int difColumna = Math.abs(destino.getColumna() - posicion.getColumna());
        if (difFila != difColumna) return false;

        int direccionFila = Integer.compare(destino.getFila(), posicion.getFila());
        int direccionColumna = Integer.compare(destino.getColumna(), posicion.getColumna());

        Posicion actual = posicion.desplazar(direccionFila, direccionColumna);
        while (!actual.equals(destino)) {
            if (tablero.getPieza(actual) != null) return false;
            actual = actual.desplazar(direccionFila, direccionColumna);
        }
        return true;
    }

    private boolean esMovimientoCaballoValido(Posicion destino) {
        int difFila = Math.abs(destino.getFila() - posicion.getFila());
        int difColumna = Math.abs(destino.getColumna() - posicion.getColumna());
        return (difFila == 2 && difColumna == 1) || (difFila == 1 && difColumna == 2);
    }

    private boolean esMovimientoTorreValido(Posicion destino, TableroAjedrez tablero) {
        if (posicion.getFila() != destino.getFila() && posicion.getColumna() != destino.getColumna()) {
            return false;
        }

        int direccionFila = Integer.compare(destino.getFila(), posicion.getFila());
        int direccionColumna = Integer.compare(destino.getColumna(), posicion.getColumna());

        Posicion actual = posicion.desplazar(direccionFila, direccionColumna);
        while (!actual.equals(destino)) {
            if (tablero.getPieza(actual) != null) return false;
            actual = actual.desplazar(direccionFila, direccionColumna);
        }
        return true;
    }
}

public class Posicion {
    private final int fila;    // fila (1-8)
    private final int columna; // columna (a-h)

    public Posicion(char columna, int fila) {
        this.columna = columna - 'a';
        this.fila = fila - 1;
    }

    public Posicion(int fila, int columna) {
        this.fila = fila;
        this.columna = columna;
    }

    public int getFila() { return fila; }
    public int getColumna() { return columna; }

    public boolean esValida() {
        return fila >= 0 && fila < 8 && columna >= 0 && columna < 8;
    }

    public Posicion desplazar(int desplazamientoFila, int desplazamientoColumna) {
        return new Posicion(fila + desplazamientoFila, columna + desplazamientoColumna);
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof Posicion)) return false;
        Posicion otro = (Posicion) obj;
        return fila == otro.fila && columna == otro.columna;
    }

    @Override
    public String toString() {
        return "" + (char)('a' + columna) + (fila + 1);
    }
}

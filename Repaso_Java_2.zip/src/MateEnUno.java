import java.io.FileReader;
import java.io.*;
import java.util.*;

public class MateEnUno {
    public static String resolverMateEnUno(String posReyNegro, List<String> piezasBlancas) {
        TableroAjedrez tablero = new TableroAjedrez();

        Posicion posicionReyNegro = new Posicion(posReyNegro.charAt(1),
                Character.getNumericValue(posReyNegro.charAt(2)));
        tablero.setReyNegro(posicionReyNegro);

        for (String piezaStr : piezasBlancas) {
            TipoPieza tipo = TipoPieza.desdeSimbolo(piezaStr.charAt(0));
            Posicion posicion = new Posicion(piezaStr.charAt(1),
                    Character.getNumericValue(piezaStr.charAt(2)));
            tablero.agregarPieza(new Pieza(tipo, posicion));
        }

        return tablero.verificarMateEnUno();
    }

    // Método para leer desde archivo
    public static void procesarArchivo(String rutaArchivo) {
        try (BufferedReader lector = new BufferedReader(new FileReader(rutaArchivo))) {
            String linea;
            while ((linea = lector.readLine()) != null) {
                if (linea.trim().isEmpty()) continue;

                String posReyNegro = linea.trim();

                linea = lector.readLine();
                if (linea == null) break;
                int numPiezas = Integer.parseInt(linea.trim());

                List<String> piezasBlancas = new ArrayList<>();
                for (int i = 0; i < numPiezas; i++) {
                    linea = lector.readLine();
                    if (linea == null) break;
                    piezasBlancas.add(linea.trim());
                }

                String resultado = resolverMateEnUno(posReyNegro, piezasBlancas);
                System.out.println(resultado);
            }
        } catch (IOException e) {
            System.err.println("Error al leer el archivo: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        if (args.length > 0) {
            procesarArchivo(args[0]);
        } else {
            Scanner scanner = new Scanner(System.in);
            while (scanner.hasNext()) {
                String posReyNegro = scanner.next();
                int numPiezas = scanner.nextInt();

                List<String> piezasBlancas = new ArrayList<>();
                for (int i = 0; i < numPiezas; i++) {
                    piezasBlancas.add(scanner.next());
                }

                System.out.println(resolverMateEnUno(posReyNegro, piezasBlancas));
            }
            scanner.close();
        }
    }
}
import java.util.*;

public class TableroAjedrez {
    private final Pieza[][] tablero;
    private Posicion posicionReyNegro;
    private final List<Pieza> piezasBlancas;

    public TableroAjedrez() {
        tablero = new Pieza[8][8];
        piezasBlancas = new ArrayList<>();
    }

    public void agregarPieza(Pieza pieza) {
        Posicion pos = pieza.getPosicion();
        tablero[pos.getFila()][pos.getColumna()] = pieza;
        if (pieza.getTipo() != TipoPieza.REY || !piezasBlancas.contains(pieza)) {
            piezasBlancas.add(pieza);
        }
    }

    public void setReyNegro(Posicion posicion) {
        posicionReyNegro = posicion;
    }

    public Pieza getPieza(Posicion posicion) {
        return tablero[posicion.getFila()][posicion.getColumna()];
    }

    public String verificarMateEnUno() {
        List<String> jugadasMate = new ArrayList<>();

        for (Pieza pieza : piezasBlancas) {
            for (int fila = 0; fila < 8; fila++) {
                for (int columna = 0; columna < 8; columna++) {
                    Posicion destino = new Posicion(fila, columna);

                    if (esJugadaMatadora(pieza, destino)) {
                        jugadasMate.add(pieza.getTipo().getSimbolo() + destino.toString());
                    }
                }
            }
        }

        if (jugadasMate.isEmpty()) return "NO";
        if (jugadasMate.size() > 1) return ">1";
        return jugadasMate.get(0);
    }

    private boolean esJugadaMatadora(Pieza pieza, Posicion destino) {
        if (!pieza.esMovimientoValido(destino, this)) return false;

        Posicion posicionOriginal = pieza.getPosicion();
        Pieza piezaCapturada = getPieza(destino);

        pieza.setPosicion(destino);
        tablero[posicionOriginal.getFila()][posicionOriginal.getColumna()] = null;
        tablero[destino.getFila()][destino.getColumna()] = pieza;

        boolean esMate = esMateAhora();

        pieza.setPosicion(posicionOriginal);
        tablero[posicionOriginal.getFila()][posicionOriginal.getColumna()] = pieza;
        tablero[destino.getFila()][destino.getColumna()] = piezaCapturada;

        return esMate;
    }

    private boolean esMateAhora() {
        if (!hayJaque()) return false;

        int[] direcciones = {-1, 0, 1};
        for (int desplazamientoFila : direcciones) {
            for (int desplazamientoColumna : direcciones) {
                if (desplazamientoFila == 0 && desplazamientoColumna == 0) continue;

                Posicion nuevaPosicion = posicionReyNegro.desplazar(desplazamientoFila, desplazamientoColumna);
                if (nuevaPosicion.esValida() && esMovimientoReyNegroValido(nuevaPosicion)) {
                    return false;
                }
            }
        }
        return true;
    }
    private boolean hayJaque() {
        for (Pieza pieza : piezasBlancas) {
            if (pieza.esMovimientoValido(posicionReyNegro, this)) {
                return true;
            }
        }
        return false;
    }
    private boolean esMovimientoReyNegroValido(Posicion destino) {
        for (Pieza pieza : piezasBlancas) {
            if (pieza.esMovimientoValido(destino, this)) {
                return false;
            }
        }
        return true;
    }
}

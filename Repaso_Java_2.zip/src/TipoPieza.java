public enum TipoPieza {
    REY('R'),
    DAMA('D'),
    ALFIL('A'),
    CABALLO('C'),
    TORRE('T');

    private final char simbolo;

    TipoPieza(char simbolo) {
        this.simbolo = simbolo;
    }

    public char getSimbolo() {
        return simbolo;
    }

    public static TipoPieza desdeSimbolo(char simbolo) {
        for (TipoPieza tipo : values()) {
            if (tipo.simbolo == simbolo) {
                return tipo;
            }
        }
        throw new IllegalArgumentException("Símbolo de pieza inválido: " + simbolo);
    }
}

